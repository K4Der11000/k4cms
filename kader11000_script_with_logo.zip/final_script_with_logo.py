
from PIL import Image, ImageTk
import os
from tkinter import Toplevel, Label

def show_logo():
    try:
        logo_path = "kader11000_logo.png"
        if not os.path.exists(logo_path):
            import shutil
            shutil.copy("/mnt/data/A_2D_digital_graphic_design_features_the_text_“kad.png", logo_path)

        logo_window = Toplevel()
        logo_window.title("kader11000 Logo")
        logo_window.configure(bg="black")

        img = Image.open(logo_path)
        img = img.resize((400, 100))
        tk_img = ImageTk.PhotoImage(img)

        label = Label(logo_window, image=tk_img, bg="black")
        label.image = tk_img
        label.pack()

        logo_window.after(3000, logo_window.destroy)
    except Exception as e:
        print(f"خطأ في عرض الشعار: {e}")


import requests
from tkinter import *
from tkinter import messagebox, scrolledtext
from bs4 import BeautifulSoup

def detect_script_type(url, output_box):
    if not url.startswith("http"):
        url = "http://" + url

    try:
        response = requests.get(url, timeout=10)
        headers = response.headers
        content = response.text.lower()
        soup = BeautifulSoup(response.text, "html.parser")

        output_box.delete("1.0", END)
        output_box.insert(END, f"رؤوس السيرفر: {headers.get('Server', 'غير معروف')}\n")
        output_box.insert(END, f"Powered By: {headers.get('X-Powered-By', 'غير معروف')}\n\n")

        # كشف نوع السكربت
        if "php" in headers.get("X-Powered-By", "").lower() or ".php" in content:
            output_box.insert(END, "✓ يبدو أن الموقع يستخدم PHP.\n")
        elif "asp.net" in headers.get("X-Powered-By", "").lower():
            output_box.insert(END, "✓ الموقع يستخدم ASP.NET.\n")
        elif "python" in headers.get("X-Powered-By", "").lower() or "django" in content or "flask" in content:
            output_box.insert(END, "✓ الموقع مبني على Python (Django/Flask).\n")
        elif ".js" in content or "javascript" in content:
            output_box.insert(END, "✓ الموقع يستخدم JavaScript.\n")
        else:
            output_box.insert(END, "× لم يتم التعرف على نوع السكربت بدقة.\n")

        # كشف CMS
        output_box.insert(END, "\nنظام إدارة المحتوى (CMS):\n")
        cms_found = False
        generator = soup.find("meta", {"name": "generator"})
        if generator:
            gen_content = generator.get("content", "").lower()
            if "wordpress" in gen_content:
                output_box.insert(END, "✓ WordPress\n")
                cms_found = True

        # عرض ثغرات أمنية مرتبطة بالـ CMS إن وجدت
        output_box.insert(END, "\nثغرات أمنية معروفة:\n")
        if "wordpress" in gen_content:
            for vuln in [
                "تأكد من تحديث WordPress والملحقات لتجنب ثغرات XSS و SQLi.",
                "النسخ القديمة عرضة للثغرات مثل CVE-2020-36326 و CVE-2019-17671."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "joomla" in gen_content:
            for vuln in [
                "إصدارات Joomla القديمة عرضة لثغرات تنفيذ التعليمات عن بعد.",
                "تأكد من تحديث Joomla لإصلاح CVE-2015-7297 و CVE-2016-9838."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "drupal" in gen_content:
            for vuln in [
                "تأكد من الحماية من ثغرة Drupalgeddon (CVE-2018-7600).",
                "النسخ غير المحدثة قد تكون عرضة لهجمات RCE."
            ]:
                output_box.insert(END, f"- {vuln}\n")

            elif "joomla" in gen_content:
                output_box.insert(END, "✓ Joomla\n")
                cms_found = True

        # عرض ثغرات أمنية مرتبطة بالـ CMS إن وجدت
        output_box.insert(END, "\nثغرات أمنية معروفة:\n")
        if "wordpress" in gen_content:
            for vuln in [
                "تأكد من تحديث WordPress والملحقات لتجنب ثغرات XSS و SQLi.",
                "النسخ القديمة عرضة للثغرات مثل CVE-2020-36326 و CVE-2019-17671."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "joomla" in gen_content:
            for vuln in [
                "إصدارات Joomla القديمة عرضة لثغرات تنفيذ التعليمات عن بعد.",
                "تأكد من تحديث Joomla لإصلاح CVE-2015-7297 و CVE-2016-9838."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "drupal" in gen_content:
            for vuln in [
                "تأكد من الحماية من ثغرة Drupalgeddon (CVE-2018-7600).",
                "النسخ غير المحدثة قد تكون عرضة لهجمات RCE."
            ]:
                output_box.insert(END, f"- {vuln}\n")

            elif "drupal" in gen_content:
                output_box.insert(END, "✓ Drupal\n")
                cms_found = True

        # عرض ثغرات أمنية مرتبطة بالـ CMS إن وجدت
        output_box.insert(END, "\nثغرات أمنية معروفة:\n")
        if "wordpress" in gen_content:
            for vuln in [
                "تأكد من تحديث WordPress والملحقات لتجنب ثغرات XSS و SQLi.",
                "النسخ القديمة عرضة للثغرات مثل CVE-2020-36326 و CVE-2019-17671."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "joomla" in gen_content:
            for vuln in [
                "إصدارات Joomla القديمة عرضة لثغرات تنفيذ التعليمات عن بعد.",
                "تأكد من تحديث Joomla لإصلاح CVE-2015-7297 و CVE-2016-9838."
            ]:
                output_box.insert(END, f"- {vuln}\n")
        elif "drupal" in gen_content:
            for vuln in [
                "تأكد من الحماية من ثغرة Drupalgeddon (CVE-2018-7600).",
                "النسخ غير المحدثة قد تكون عرضة لهجمات RCE."
            ]:
                output_box.insert(END, f"- {vuln}\n")

        if not cms_found:
            output_box.insert(END, "× لم يتم التعرف على CMS.\n")

    except requests.RequestException as e:
        messagebox.showerror("خطأ", f"فشل الاتصال بالموقع:\n{e}")

def create_gui():
    show_logo()
    root = Tk()
    root.title("كشف السكربت و CMS - kader11000")
    root.geometry("500x450")
    root.configure(bg="#101010")

    Label(root, text="أدخل رابط الموقع:", bg="#101010", fg="lightgreen", font=("Courier", 12)).pack(pady=10)
    url_entry = Entry(root, font=("Courier", 11), width=50)
    url_entry.pack(pady=5)

    output_box = scrolledtext.ScrolledText(root, font=("Courier", 10), width=60, height=17, bg="#111", fg="lime")
    output_box.pack(pady=10)

    def on_click():
        url = url_entry.get()
        detect_script_type(url, output_box)

    Button(root, text="فحص", command=on_click, bg="green", fg="white", font=("Courier", 11)).pack(pady=10)
    root.mainloop()

create_gui()
